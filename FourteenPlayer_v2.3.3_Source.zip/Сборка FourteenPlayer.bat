@echo off
chcp 65001 > nul
title Сборка FourteenPlayer v2.3.3
cd /d "%~dp0"
echo ========================================================
echo  Сборка FourteenPlayer v2.3.3 (Release)...
echo ========================================================
echo.
dotnet publish FourteenPlayer.csproj -c Release -o "%~dp0publish"
if %errorlevel% equ 0 (
    echo.
    echo ========================================================
    echo  [УСПЕХ] FourteenPlayer v2.3.3 собран успешно!
    echo  Файл: %~dp0publish\FourteenPlayer.exe
    echo ========================================================
) else (
    echo.
    echo [ОШИБКА] Ошибка при сборке!
)
pause