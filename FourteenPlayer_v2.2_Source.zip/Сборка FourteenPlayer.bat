﻿@echo off
chcp 65001 > nul
title Сборка FourteenPlayer v2.2
cd /d "%~dp0"
echo ========================================================
echo  Сборка FourteenPlayer v2.2 (Release)...
echo ========================================================
echo.
dotnet publish FourteenPlayer.csproj -c Release -o "%~dp0publish"
if %errorlevel% equ 0 (
    echo.
    echo ========================================================
    echo  [УСПЕХ] FourteenPlayer v2.2 собран успешно!
    echo  Путь: %~dp0publish\FourteenPlayer.exe
    echo ========================================================
) else (
    echo.
    echo [ОШИБКА] Ошибка при сборке!
)
pause