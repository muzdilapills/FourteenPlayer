using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace FourteenPlayer;

public class PlaylistModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; } = "";
    public List<string> TrackPaths { get; set; } = new();
}

public class PlayerSettings
{
    public double Volume { get; set; } = 0.7;
    public bool IsMuted { get; set; } = false;
    public bool IsShuffle { get; set; } = false;
    public int RepeatMode { get; set; } = 1; // 0: Off, 1: Repeat List, 2: Repeat Album, 3: Repeat Track
    public int LastTrackIndex { get; set; } = 0;
    public List<string> PlaylistFiles { get; set; } = new();

    // User Profile
    public string Nickname { get; set; } = "";

    // Personalization Settings
    public string CustomCoverPath { get; set; } = "";
    public string CustomCoverDiscordUrl { get; set; } = "";
    public bool EnablePlaylists { get; set; } = true;
    public bool MinimizeToTray { get; set; } = true;

    // Playlists data
    public List<PlaylistModel> Playlists { get; set; } = new();
    public string ActivePlaylistName { get; set; } = "Добавленное";
    public List<string> OpenPlaylistNames { get; set; } = new();

    // Discord Rich Presence settings
    public bool EnableDiscordRpc { get; set; } = true;
    public string DiscordClientId { get; set; } = "383226320970055681";

    public static string AppDataDirectory =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FourteenPlayer");

    private static string SettingsFilePath =>
        Path.Combine(AppDataDirectory, "settings.json");

    public static string NicknameFilePath =>
        Path.Combine(AppDataDirectory, "nickname.txt");

    private static string OldSettingsFilePath =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LitePlayer", "settings.json");

    public static PlayerSettings Load()
    {
        PlayerSettings settings = new();
        try
        {
            string path = SettingsFilePath;
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                var loaded = JsonSerializer.Deserialize<PlayerSettings>(json);
                if (loaded != null) settings = loaded;
            }
            else if (File.Exists(OldSettingsFilePath))
            {
                string json = File.ReadAllText(OldSettingsFilePath);
                var loaded = JsonSerializer.Deserialize<PlayerSettings>(json);
                if (loaded != null)
                {
                    settings = loaded;
                    settings.Save();
                }
            }
        }
        catch { }

        // If nickname is empty in settings, check nickname.txt
        try
        {
            if (string.IsNullOrWhiteSpace(settings.Nickname) && File.Exists(NicknameFilePath))
            {
                string savedNick = File.ReadAllText(NicknameFilePath, Encoding.UTF8).Trim();
                if (!string.IsNullOrWhiteSpace(savedNick))
                {
                    settings.Nickname = savedNick;
                }
            }
        }
        catch { }

        return settings;
    }

    public void Save()
    {
        try
        {
            string path = SettingsFilePath;
            string? dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            string json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, json, Encoding.UTF8);

            // Also synchronize nickname.txt
            if (!string.IsNullOrWhiteSpace(Nickname))
            {
                File.WriteAllText(NicknameFilePath, Nickname, Encoding.UTF8);
            }
        }
        catch { }
    }
}
